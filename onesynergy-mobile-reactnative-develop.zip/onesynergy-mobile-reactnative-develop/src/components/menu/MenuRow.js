import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';
import React from 'react';
import {COLORS} from '../../constants/theme';
import {assets} from '../../constants';

const MenuRow = ({Title, Subtitle, ImageUrl, onPress}) => {
  return (
    <TouchableOpacity style={styles.row} onPress={onPress}>
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          marginStart: 20,
        }}>
        <Text
          style={{
            fontSize: 18,
            fontWeight: '700',
            marginBottom: 5,
          }}>
          {Title}
        </Text>
        <Text
          style={{
            color: COLORS.grey_tabbar,
            fontWeight: '500',
            fontSize: 15,
          }}>
          {Subtitle}
        </Text>
      </View>
      <View style={styles.imageContainer}>
        <Image source={ImageUrl} style={styles.image} />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  row: {
    borderRadius: 10,
    height: 90,
    marginHorizontal: 20,
    backgroundColor: 'white',
    marginTop: 20,
    flexDirection: 'row',
    borderWidth: 0.1,
    borderColor: 'black',
  },
  imageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    height: 90,
    width: 90,
    resizeMode: 'contain',
  },
});

export default MenuRow;
