import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  StatusBar,
} from 'react-native';
import React from 'react';
import {COLORS} from '../../constants/theme';
import Icon from 'react-native-vector-icons/Ionicons';

const Header = ({ScreenTitle, HasWeather = false}) => {
  return (
    <View>
      <SafeAreaView
        style={{
          backgroundColor: COLORS.blue_primary_bg,
          height: 80,
          flexDirection: 'row',
        }}>
        <StatusBar barStyle="light-content" />

        {/* Header */}

        <View style={styles.headerContainer}>
          <Text style={styles.welcomeText}>{ScreenTitle}</Text>
          {HasWeather ? (
            <Image
              source={{
                uri: 'https://cdn.weatherapi.com/weather/64x64/day/116.png',
              }}
              style={styles.weatherImg}
            />
          ) : null}
        </View>
        <View style={{flex: 0.1, marginEnd: 10}}>
          <Icon
            name="chatbubble-outline"
            size={24}
            color={'white'}
            style={styles.chatIcon}
          />
        </View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    marginBottom: 10,
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'center',
    marginStart: 50,
  },
  welcomeText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 3,
  },
  weatherImg: {
    width: 30,
    height: 30,
  },
  chatIcon: {
    height: 24,
    width: 24,
  },
});

export default Header;
