import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import {COLORS} from '../../../constants/theme';

const SettingRowWithIcon = ({
  imageUrl,
  rowName,
  onPress,
  imageStyle,
  imageContainer,
  textStyle,
  visibleIcon = false,
}) => {
  return (
    <View>
      <TouchableOpacity style={styles.container} onPress={onPress}>
        <View style={[styles.imageContainer, imageContainer]}>
          <Image source={imageUrl} style={[styles.image, imageStyle]} />
        </View>
        <View style={styles.textContainer}>
          <Text
            style={[
              {
                fontSize: 18,
              },
              textStyle,
            ]}>
            {rowName}
          </Text>
        </View>
        <View style={styles.iconContainer}>
          {visibleIcon ? (
            <Icon
              name="chevron-forward-outline"
              size={25}
              color={COLORS.grey_btn}
            />
          ) : null}
        </View>
      </TouchableOpacity>
      <View
        style={{
          height: 1,
          backgroundColor: COLORS.grey_bg,
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    height: 36,
    width: 36,
    resizeMode: 'cover',
  },
  imageContainer: {
    backgroundColor: COLORS.light_blue_button,
    padding: 1,
    borderRadius: 24,
    marginStart: 20,
  },
  textContainer: {
    flex: 8,
    marginStart: 25,
  },
  iconContainer: {
    flex: 1,
  },
});

export default SettingRowWithIcon;
