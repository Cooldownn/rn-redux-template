import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';
import React from 'react';
import {COLORS} from '../../../constants/theme';

const SettingRowWithText = ({
  imageUrl,
  rowName,
  onPress,
  lastText,
  imageStyle,
  imageContainer,
  textStyle,
  lastTextContainerStyle,
}) => {
  return (
    <View>
      <TouchableOpacity style={styles.container} onPress={onPress}>
        <View style={[styles.imageContainer, imageContainer]}>
          <Image source={imageUrl} style={[styles.image, imageStyle]} />
        </View>
        <View style={styles.textContainer}>
          <Text
            style={{
              fontSize: 18,
            }}>
            {rowName}
          </Text>
        </View>
        <View style={[styles.lastTextContainer, lastTextContainerStyle]}>
          <Text style={[styles.text, textStyle]}>{lastText}</Text>
        </View>
      </TouchableOpacity>
      <View
        style={{
          height: 1,
          backgroundColor: COLORS.grey_bg,
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    height: 36,
    width: 36,
    resizeMode: 'cover',
  },
  imageContainer: {
    backgroundColor: COLORS.light_blue_button,
    padding: 1,
    borderRadius: 24,
    marginStart: 20,
  },
  textContainer: {
    flex: 8,
    marginStart: 25,
  },
  lastTextContainer: {
    flex: 5,
  },
  text: {
    fontSize: 17,
  },
});

export default SettingRowWithText;
