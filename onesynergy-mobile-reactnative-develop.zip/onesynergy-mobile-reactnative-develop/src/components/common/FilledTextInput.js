import { View, Text, TextInput, StyleSheet, Image } from 'react-native';
import React from 'react';
import { assets } from '../../constants';

export const FilledTextInput = ({
  placeholder,
  imageSource,
  imageStyle,
  inputStyle,
  styleContainer,
  onChangeText,
  keyboardType,
  autoCapitalize,
  value,
}) => {
  return (
    <View style={[styles.container, styleContainer]}>
      <Image source={imageSource} style={imageStyle} />
      <TextInput
        placeholder={placeholder}
        style={inputStyle}
        onChangeText={onChangeText}
        value={value}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    height: 50,
    borderRadius: 8,
    flexDirection: 'row',
  },
});
