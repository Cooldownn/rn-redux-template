import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Image,
} from 'react-native';
import React, {useState, useRef} from 'react';
import Carousel from 'react-native-snap-carousel';
import {assets} from '../../constants';

const SLIDER_WIDTH = Dimensions.get('window').width + 130;
const ITEM_WIDTH = Math.round(SLIDER_WIDTH * 0.5);

const SliderItems = () => {
  const [carouselItem, setCarouselItem] = useState([
    {
      title: 'Vaccine Declaration',
      image: assets.ic_vaccine_declaration,
    },
    {
      title: 'Marketing Campaign',
      image: assets.ic_inform_marketing,
    },
  ]);
  const isCarousel = useRef(null);

  const renderCarouselItem = ({item, index}) => {
    return (
      <TouchableOpacity style={{}}>
        <Image
          source={item.image}
          style={{
            width: 256,
            height: 120,
            resizeMode: 'cover',
          }}
        />
        <View
          style={{
            backgroundColor: 'white',
            height: 50,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontSize: 17,
              fontWeight: '500',
            }}>
            {item.title}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Carousel
      layout={'default'}
      ref={isCarousel}
      data={carouselItem}
      sliderWidth={SLIDER_WIDTH}
      itemWidth={ITEM_WIDTH}
      renderItem={renderCarouselItem}
      activeSlideAlignment={'start'}
      containerCustomStyle={styles.carouselContainer}
    />
  );
};

const styles = StyleSheet.create({
  carouselContainer: {
    marginStart: 20,
  },
});

export default SliderItems;
