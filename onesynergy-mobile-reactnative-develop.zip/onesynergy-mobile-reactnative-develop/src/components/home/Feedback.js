import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {COLORS} from '../../constants/theme';

const Feedback = () => {
  const onFeedbackPressed = () => {
    console.log('Feedback Pressed');
  };

  return (
    <TouchableOpacity onPress={onFeedbackPressed}>
      <Text
        style={{
          color: COLORS.blue_label,
          fontSize: 18,
        }}>
        Help feedback about this page?
      </Text>
    </TouchableOpacity>
  );
};

export default Feedback;
