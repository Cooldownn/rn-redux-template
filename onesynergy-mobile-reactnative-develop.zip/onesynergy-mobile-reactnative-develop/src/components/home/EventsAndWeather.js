import {View, Text, Image, StyleSheet} from 'react-native';
import React from 'react';
import {COLORS} from '../../constants/theme';

const EventsAndWeather = ({
  eventType,
  eventData = null,
  weatherData,
  noEventText,
  style = null,
}) => {
  return (
    <View style={style}>
      <View style={{flexDirection: 'row'}}>
        <Text
          style={{
            fontWeight: '600',
            fontSize: 22,
          }}>
          {eventType}
        </Text>
        <View
          style={{
            alignItems: 'flex-end',
            flex: 1,
            marginEnd: 16,
          }}>
          <View
            style={{flexDirection: 'row', alignItems: 'center', marginEnd: 5}}>
            <Image
              source={{
                uri: 'https://cdn.weatherapi.com/weather/64x64/day/116.png',
              }}
              style={styles.weatherImg}
            />
            <Text
              style={{
                fontSize: 16,
                color: COLORS.grey_tabbar,
                fontWeight: '500',
                marginStart: 5,
              }}>
              {weatherData} °C
            </Text>
          </View>
        </View>
      </View>
      {eventData ? null : (
        <Text
          style={{
            color: COLORS.grey_tabbar,
            marginTop: 12,
            fontSize: 18,
          }}>
          {noEventText}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  weatherImg: {
    width: 30,
    height: 30,
  },
});

export default EventsAndWeather;
