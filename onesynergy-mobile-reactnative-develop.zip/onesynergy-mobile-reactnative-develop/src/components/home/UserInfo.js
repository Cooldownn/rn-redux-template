import {View, Text, TouchableOpacity, StyleSheet, Image} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import {COLORS} from '../../constants/theme';
import {assets} from '../../constants';

const UserInfo = ({img, username, role}) => {
  return (
    <TouchableOpacity style={styles.profileContainer}>
      <Image
        source={img == '' ? assets.error_image : img}
        style={styles.userAvatar}
      />
      <View style={styles.nameroleContainer}>
        <Text
          style={{
            fontWeight: '600',
            fontSize: 24,
          }}>
          {username}
        </Text>
        <Text
          style={{
            fontWeight: '400',
            fontSize: 20,
          }}>
          {role}
        </Text>
      </View>
      <View style={styles.nextIcon}>
        <Icon
          name="chevron-forward-outline"
          size={25}
          color={COLORS.grey_btn}
        />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  profileContainer: {
    flexDirection: 'row',
    height: 120,
    backgroundColor: 'white',
  },
  nameroleContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    paddingStart: 20,
  },
  userAvatar: {
    width: 120,
    height: 120,
    resizeMode: 'contain',
  },
  nextIcon: {
    justifyContent: 'center',
    flex: 1,
    alignItems: 'flex-end',
    marginEnd: 16,
  },
});

export default UserInfo;
