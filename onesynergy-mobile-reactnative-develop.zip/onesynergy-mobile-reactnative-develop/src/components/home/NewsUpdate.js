import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import {COLORS} from '../../constants/theme';

const NewsUpdate = () => {
  return (
    <TouchableOpacity style={styles.updateContainer}>
      <Icon
        name="star-outline"
        size={15}
        color={'yellow'}
        style={{marginStart: 20}}
      />
      <Text
        style={{
          color: 'white',
          fontSize: 15,
          fontWeight: '500',
          marginStart: 10,
          marginTop: 2,
        }}>
        See what's new in this update
      </Text>
      <View style={{alignItems: 'flex-end', flex: 1, marginEnd: 16}}>
        <Icon name="chevron-forward-outline" size={25} color={'white'} />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  updateContainer: {
    height: 50,
    backgroundColor: COLORS.blue_label,
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default NewsUpdate;
