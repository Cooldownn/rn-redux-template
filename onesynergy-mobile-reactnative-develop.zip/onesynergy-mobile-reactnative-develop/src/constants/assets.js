import splash_logo from '../assets/images/splash_logo.png';
import synergy_logo from '../assets/images/synergy_logo.png';
import synergy_logo_white from '../assets/images/synergy_logo_white.png';
import ic_mail from '../assets/images/ic_mail.png';
import ic_padlock from '../assets/images/ic_padlock.png';
import ic_eye from '../assets/images/ic_eye.png';
import ic_eye_off from '../assets/images/ic_eye_off.png';
import ic_delete from '../assets/images/ic_delete.png';
import back_icon from '../assets/images/back_icon.png';
import ic_home from '../assets/images/ic_home.png';
import ic_shortcuts from '../assets/images/ic_shortcuts.png';
import ic_scanner from '../assets/images/ic_scanner.png';
import ic_notification from '../assets/images/ic_notification.png';
import ic_profile from '../assets/images/ic_profile.png';
import ic_chevron_right from '../assets/images/ic_chevron_right.png';
import ic_vaccine_declaration from '../assets/images/ic_vaccine_declaration.png';
import ic_inform_marketing from '../assets/images/ic_inform_marketing.png';
import menu_about_synergy from '../assets/images/menu_about_synergy.png';
import menu_calendar from '../assets/images/menu_calendar.png';
import menu_collect_requisition from '../assets/images/menu_collect_requisition.png';
import menu_elearning from '../assets/images/menu_elearning.png';
import menu_invite_user from '../assets/images/menu_invite_user.png';
import menu_my_booking from '../assets/images/menu_my_booking.png';
import menu_namecard from '../assets/images/menu_namecard.png';
import menu_requisition from '../assets/images/menu_requisition.png';
import menu_room_booking_covid_update from '../assets/images/menu_room_booking_covid_update.png';
import menu_service_request from '../assets/images/menu_service_request.png';
import menu_sim_app from '../assets/images/menu_sim_app.png';
import error_image from '../assets/images/error_image.png';
import ic_camera from '../assets/images/ic_camera.png';
import ic_feedback from '../assets/images/ic_feedback.png';
import ic_info from '../assets/images/ic_info.png';
import ic_location from '../assets/images/ic_location.png';
import ic_lock from '../assets/images/ic_lock.png';
import ic_logout from '../assets/images/ic_logout.png';
import ic_notification_blue from '../assets/images/ic_notification_blue.png';
import ic_reinstall from '../assets/images/ic_reinstall.png';
import ic_sun_moon from '../assets/images/ic_sun_moon.png';

export default {
  splash_logo,
  synergy_logo,
  synergy_logo_white,
  ic_mail,
  ic_padlock,
  ic_eye,
  ic_eye_off,
  ic_delete,
  back_icon,
  ic_home,
  ic_shortcuts,
  ic_scanner,
  ic_notification,
  ic_profile,
  ic_chevron_right,
  ic_vaccine_declaration,
  ic_inform_marketing,
  menu_about_synergy,
  menu_calendar,
  menu_collect_requisition,
  menu_elearning,
  menu_invite_user,
  menu_my_booking,
  menu_namecard,
  menu_requisition,
  menu_room_booking_covid_update,
  menu_service_request,
  menu_sim_app,
  error_image,
  ic_camera,
  ic_feedback,
  ic_info,
  ic_location,
  ic_lock,
  ic_logout,
  ic_notification_blue,
  ic_reinstall,
  ic_sun_moon,
};
