import {Dimensions} from 'react-native';

import assets from './assets';

export {assets};

export const uat_env = 'development';
export const prod_env = 'production';
export const ENV = 'env';

export const BASE_URL = 'BASE_URL';

export const APP_PIN = 'APP_PIN';

export const SCREEN_WIDTH = Dimensions.get('screen').width;
export const SCREEN_HEIGHT = Dimensions.get('screen').height;

export const ACCESS_TOKEN = 'access_token';
export const REFRESH_TOKEN = 'refresh_token';
export const USER_ID = 'userId';
export const USER_NAME = 'userName';
export const IS_VERIFIED = 'isVerified';
export const IS_ADVISER = 'isAdviser';
export const BIOMETRIC = 'biometric';
export const IS_LOGGEDIN = 'isLoggedIn';
