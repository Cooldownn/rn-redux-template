export const COLORS = {
  blue_primary_bg: '#233876',
  blue_primary_btn: '#1C64F2',
  grey_tabbar: '#818181',
  grey_btn: '#AFAFAF',
  grey_bg: '#F4F5F7',
  blue_label: '#3263E9',
  light_blue_bg: '#F2F8FE',
  light_blue_button: '#3263E9',
};
