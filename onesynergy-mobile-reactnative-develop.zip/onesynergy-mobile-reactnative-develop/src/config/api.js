export const UAT_BASE_URL = 'https://1uat.synergy.com.sg/service';
export const PROD_BASE_URL = 'https://1.synergy.com.sg/service';

export const LOGIN_URL = '/token';
export const USER_DATA_URL = '/api/account/';
