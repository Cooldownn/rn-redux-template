import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import Header from '../../../components/common/Header';
import {COLORS} from '../../../constants/theme';
import {assets} from '../../../constants';
import SettingRowWithIcon from '../../../components/common/settings/SettingRowWithIcon';
import SettingRowWithText from '../../../components/common/settings/SettingRowWithText';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch} from 'react-redux';
import {SET_LOGOUT_REQUEST} from '../../auth/model/actions';

const SettingScreen = () => {
  const dispatch = useDispatch();

  const onApperancePressed = () => {
    console.log('Appearance Pressed');
  };

  const onSecurityPressed = () => {
    console.log('Security Pressed');
  };

  const onFeedbackPressed = () => {
    console.log('Feedback Pressed');
  };

  const onAppVersionPressed = () => {
    console.log('App Version Pressed');
  };

  const onReinstallAppPressed = () => {
    console.log('Reinstall Pressed');
  };

  const onLogoutPressed = () => {
    AsyncStorage.clear();
    dispatch({
      type: SET_LOGOUT_REQUEST,
    });
  };

  return (
    <View style={{paddingBottom: 60}}>
      <Header ScreenTitle={'Settings'} />
      <ScrollView style={{backgroundColor: COLORS.grey_bg}}>
        {/* User Profile */}
        <View
          style={{
            height: 220,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: COLORS.light_blue_bg,
          }}>
          <Image source={assets.error_image} style={styles.errorImage} />
          <Text style={styles.userName}>Hung</Text>
          <Text style={styles.userRole}>Mobile Developer</Text>
        </View>

        {/* Settings */}
        <View>
          <SettingRowWithIcon
            imageUrl={assets.ic_sun_moon}
            rowName={'Appearance'}
            imageContainer={{
              borderRadius: 20,
              padding: 8,
            }}
            imageStyle={{
              width: 24,
              height: 24,
            }}
            visibleIcon={true}
            onPress={onApperancePressed}
          />
          <SettingRowWithIcon
            imageUrl={assets.ic_lock}
            rowName={'Security'}
            visibleIcon={true}
            onPress={onSecurityPressed}
          />
          <SettingRowWithIcon
            imageUrl={assets.ic_feedback}
            rowName={'Feedback'}
            visibleIcon={true}
            onPress={onFeedbackPressed}
          />
          <SettingRowWithIcon
            imageUrl={assets.ic_info}
            rowName={'App Version'}
            visibleIcon={true}
            onPress={onAppVersionPressed}
          />
          <SettingRowWithIcon
            imageUrl={assets.ic_reinstall}
            rowName={'Reinstall App'}
            onPress={onReinstallAppPressed}
          />
          <SettingRowWithIcon
            imageUrl={assets.ic_logout}
            rowName={'Logout'}
            textStyle={{color: 'red'}}
            onPress={onLogoutPressed}
          />
        </View>

        <View
          style={{
            marginTop: 20,
          }}>
          <SettingRowWithText
            imageUrl={assets.ic_location}
            rowName={'Location'}
            lastText={'Tap to enable'}
            textStyle={{color: 'red'}}
          />
          <SettingRowWithText
            imageUrl={assets.ic_notification_blue}
            rowName={'Notification'}
            lastText={'Enabled'}
            textStyle={{
              color: COLORS.grey_tabbar,
            }}
            lastTextContainerStyle={{
              flex: 3,
            }}
          />
          <SettingRowWithText
            imageUrl={assets.ic_camera}
            rowName={'Camera'}
            lastText={'Enabled'}
            textStyle={{
              color: COLORS.grey_tabbar,
            }}
            lastTextContainerStyle={{
              flex: 3,
            }}
          />
        </View>
        <View
          style={{
            height: 50,
            flex: 1,
            backgroundColor: 'transparent',
          }}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  errorImage: {
    height: 100,
    width: 100,
    resizeMode: 'cover',
    borderRadius: 50,
  },
  userName: {
    fontSize: 25,
    fontWeight: '700',
    marginTop: 20,
  },
  userRole: {
    fontSize: 20,
  },
});

export default SettingScreen;
