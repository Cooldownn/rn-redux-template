import {View, StyleSheet, ScrollView} from 'react-native';
import React from 'react';
import Header from '../../../components/common/Header';
import {COLORS} from '../../../constants/theme';
import {assets} from '../../../constants';
import MenuRow from '../../../components/menu/MenuRow';

const MenuScreen = () => {
  const onAboutPressed = () => {
    console.log('About Pressed');
  };
  const onCalendarPressed = () => {
    console.log('Calendar Pressed');
  };
  const onRoomBookingPressed = () => {
    console.log('Room Booking Pressed');
  };
  const onMyBookingPressed = () => {
    console.log('My Booking Pressed');
  };
  const onSimAppPressed = () => {
    console.log('SIM App Pressed');
  };
  const onServicePressed = () => {
    console.log('Service Request Pressed');
  };
  return (
    <View
      style={{
        paddingBottom: 60,
      }}>
      <Header ScreenTitle={'Menu'} />
      <ScrollView style={styles.container}>
        <MenuRow
          Title={'About Synergy'}
          Subtitle={'Vision, Mission, Core Values'}
          ImageUrl={assets.menu_about_synergy}
          onPress={onAboutPressed}
        />
        <MenuRow
          Title={'Calendar'}
          Subtitle={'View upcoming events'}
          ImageUrl={assets.menu_calendar}
          onPress={onCalendarPressed}
        />
        <MenuRow
          Title={'Room Booking'}
          Subtitle={'Book anytime anywhere'}
          ImageUrl={assets.menu_room_booking_covid_update}
          onPress={onRoomBookingPressed}
        />
        <MenuRow
          Title={'My Booking'}
          Subtitle={'View current appointments'}
          ImageUrl={assets.menu_my_booking}
          onPress={onMyBookingPressed}
        />
        <MenuRow
          Title={'SIM APP'}
          Subtitle={'Synergy Insurance Matrix'}
          ImageUrl={assets.menu_sim_app}
          onPress={onSimAppPressed}
        />
        <MenuRow
          Title={'Service Request'}
          Subtitle={'Having issues? Create a ticket'}
          ImageUrl={assets.menu_service_request}
          onPress={onServicePressed}
        />
        <View
          style={{
            height: 50,
            flex: 1,
            backgroundColor: 'transparent',
          }}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.grey_bg,
  },
});

export default MenuScreen;
