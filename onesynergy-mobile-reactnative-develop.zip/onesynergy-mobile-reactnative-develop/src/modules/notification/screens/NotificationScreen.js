import {View, Text} from 'react-native';
import React from 'react';
import Header from '../../../components/common/Header';

const NotificationScreen = () => {
  return (
    <View>
      <Header ScreenTitle={'Notification'} />
    </View>
  );
};

export default NotificationScreen;
