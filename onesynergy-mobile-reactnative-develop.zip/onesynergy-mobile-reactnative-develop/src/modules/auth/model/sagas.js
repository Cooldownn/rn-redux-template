import {call, put, takeEvery, takeLatest} from 'redux-saga/effects';
import {LOGIN_URL} from '../../../config/api';
import {queryApi} from '../../../redux/query-api';
import {
  UAT_SIGNIN_REQUEST,
  UAT_SIGNIN_SUCCESS,
  UAT_SIGNIN_FAILURE,
  PROD_SIGNIN_REQUEST,
  PROD_SIGNIN_SUCCESS,
  PROD_SIGNIN_FAILURE,
  SET_LOGIN_SUCCESS,
  SET_LOGIN_REQUEST,
  SET_LOGOUT_SUCCESS,
  SET_LOGOUT_REQUEST,
} from './actions';

function* authHandler() {
  yield takeLatest(UAT_SIGNIN_REQUEST, uatSignIn);
  yield takeLatest(PROD_SIGNIN_REQUEST, prodSignIn);
  yield takeLatest(SET_LOGIN_REQUEST, setPinSuccess);
  yield takeLatest(SET_LOGOUT_REQUEST, requestLogout);
}

function* uatSignIn(action) {
  try {
    const authResponse = yield call(queryApi, {
      endpoint: LOGIN_URL,
      method: 'POST',
      body: {
        username: action.payload.email,
        password: action.payload.password,
        grant_type: 'password',
      },
    });

    if (
      authResponse.status == 200 ||
      authResponse.status == 201 ||
      authResponse.status == 204
    ) {
      yield put({
        type: UAT_SIGNIN_SUCCESS,
        payload: authResponse.response,
      });
    } else {
      yield put({
        type: UAT_SIGNIN_FAILURE,
        payload: authResponse.error_response,
      });
    }
  } catch (err) {
    yield put({
      type: UAT_SIGNIN_FAILURE,
      payload: err,
    });
    console.error('error', err);
  }
}

function* prodSignIn(action) {
  try {
    const authResponse = yield call(queryApi, {
      endpoint: LOGIN_URL,
      method: 'POST',
      body: {
        username: action.payload.email,
        password: action.payload.password,
        grant_type: '2fa',
        code: action.payload.code,
      },
    });

    if (
      authResponse.status == 200 ||
      authResponse.status == 201 ||
      authResponse.status == 204
    ) {
      yield put({
        type: PROD_SIGNIN_SUCCESS,
        payload: authResponse.response,
      });
    } else {
      yield put({
        type: PROD_SIGNIN_FAILURE,
        payload: authResponse.error_response,
      });
    }
  } catch (err) {
    yield put({
      type: PROD_SIGNIN_FAILURE,
      payload: err,
    });
  }
}

function* setPinSuccess(action) {
  yield put({
    type: SET_LOGIN_SUCCESS,
    payload: true,
  });
}

function* requestLogout(action) {
  yield put({
    type: SET_LOGOUT_SUCCESS,
    payload: true,
  });
}

export {authHandler};
