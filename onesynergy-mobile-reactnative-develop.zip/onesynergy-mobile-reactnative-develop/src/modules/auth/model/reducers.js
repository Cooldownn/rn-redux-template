import {
  PROD_SIGNIN_FAILURE,
  PROD_SIGNIN_REQUEST,
  PROD_SIGNIN_SUCCESS,
  SET_LOGIN_REQUEST,
  SET_LOGIN_SUCCESS,
  SET_LOGOUT_REQUEST,
  SET_LOGOUT_SUCCESS,
  UAT_SIGNIN_FAILURE,
  UAT_SIGNIN_REQUEST,
  UAT_SIGNIN_SUCCESS,
} from './actions';

const initialState = {
  isLoggedIn: false,
  accessToken: '',
  tokenType: '',
  expiresIn: 86400,
  refreshToken: '',
  userName: '',
  userId: '',
  twoFactor: '',
  isAdviser: false,
  issue: '',
  expires: '',
  loading: false,
  error: '',
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case UAT_SIGNIN_REQUEST:
      return {
        ...state,
        loading: true,
        error: '',
      };
    case UAT_SIGNIN_SUCCESS:
      return {
        ...state,
        accessToken: action.payload.access_token ?? '',
        tokenType: action.payload.token_type ?? '',
        expiresIn: action.payload.expires_in ?? 86400,
        refreshToken: action.payload.refresh_token ?? '',
        userName: action.payload.userName ?? '',
        userId: action.payload.userId ?? '',
        twoFactor: action.payload['2FA'] ?? '',
        isAdviser: action.payload.is_adviser ?? '',
        issue: action.payload['.issued'] ?? '',
        expires: action.payload['.expires'] ?? '',
        isLoggedIn: false, // Since not set pin code yet
        loading: false,
        error: '',
      };

    case UAT_SIGNIN_FAILURE:
      return {
        loading: false,
        error: action.payload.error_description,
      };

    case PROD_SIGNIN_REQUEST:
      return {
        ...state,
        loading: true,
        error: '',
      };

    case PROD_SIGNIN_SUCCESS:
      return {
        accessToken: action.payload.access_token ?? '',
        tokenType: action.payload.token_type ?? '',
        expiresIn: action.payload.expires_in ?? 86400,
        refreshToken: action.payload.refresh_token ?? '',
        userName: action.payload.userName ?? '',
        userId: action.payload.userId ?? '',
        twoFactor: action.payload['2FA'] ?? '',
        isAdviser: action.payload.is_adviser ?? '',
        issue: action.payload['.issued'] ?? '',
        expires: action.payload['.expires'] ?? '',
        isLoggedIn: false, // Since not set pin code yet
        loading: false,
        error: '',
        ...state,
      };

    case PROD_SIGNIN_FAILURE:
      return {
        loading: false,
        error: action.payload.error_description,
      };

    case SET_LOGIN_REQUEST:
      return {
        ...state,
        loading: false,
        error: '',
      };

    case SET_LOGIN_SUCCESS:
      return {
        ...state,
        isLoggedIn: true,
        loading: false,
        error: '',
      };

    case SET_LOGOUT_REQUEST:
      return {
        ...state,
      };

    case SET_LOGOUT_SUCCESS:
      return {
        isLoggedIn: false,
      };

    default:
      return state;
  }
};

export {authReducer};
