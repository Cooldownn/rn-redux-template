import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React, {useState, useRef, useEffect} from 'react';
import {
  ACCESS_TOKEN,
  assets,
  BASE_URL,
  ENV,
  IS_ADVISER,
  IS_VERIFIED,
  prod_env,
  REFRESH_TOKEN,
  uat_env,
  USER_ID,
  USER_NAME,
} from '../../../constants';
import {FilledTextInput} from '../../../components/common/FilledTextInput';
import RBSheet from 'react-native-raw-bottom-sheet';
import AsyncStorage from '@react-native-async-storage/async-storage';
import routes from '../../../constants/routes';
import {PROD_BASE_URL, UAT_BASE_URL} from '../../../config/api';
import {useSelector, useDispatch} from 'react-redux';
import LoadingIndicator from '../../../components/common/LoadingIndicator';
import axios from 'axios';
import qs from 'qs';
import {UAT_SIGNIN_REQUEST} from '../model/actions';
import {getStringFromLocalStorage, isEmpty} from '../../../helpers';
import {COLORS} from '../../../constants/theme';

export const LoginScreen = ({navigation}) => {
  const [email, setEmail] = useState('hungdang@synergy.com.sg');
  const [password, setPassword] = useState('Concho!23');
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [securePassword, setSecurePassword] = useState(true);
  const [tappedCount, setTappedCount] = useState(1);
  const [currentEnvironment, setCurrentEnvironment] = useState('');
  const {authReducer} = useSelector(state => state);

  const dispatch = useDispatch();

  useEffect(() => {
    if (authReducer.accessToken) {
      saveUserInfo();
      // TODO: Register device
      navigation.navigate(routes.PINCODE_SCREEN);
    }
    if (authReducer.error) {
      alert(authReducer.auth.error);
    }
  }, [authReducer]);

  const refRBSheet = useRef();

  const saveUserInfo = () => {
    AsyncStorage.setItem(ACCESS_TOKEN, authReducer.accessToken ?? '');
    AsyncStorage.setItem(REFRESH_TOKEN, authReducer.refreshToken ?? '');
    AsyncStorage.setItem(USER_ID, authReducer.userId ?? '');
    AsyncStorage.setItem(USER_NAME, authReducer.userName ?? '');
    AsyncStorage.setItem(IS_ADVISER, authReducer.isAdviser ?? '');
    AsyncStorage.setItem(IS_VERIFIED, 'true');
  };

  const onEmailChange = value => {
    setEmail(value);
  };

  const onPasswordChange = value => {
    setPassword(value);
  };

  const onVisiblePress = () => {
    setVisiblePassword(!visiblePassword);
    setSecurePassword(visiblePassword);
  };

  const loginPressed = async () => {
    // console.log('email', email);
    // console.log('password', password);
    if (isEmpty(email)) return alert('Email cannot be empty');
    if (isEmpty(password)) return alert('Password cannot be empty');
    // TODO: Change environment to PRODUCTION
    const currentEnv = (await getStringFromLocalStorage(ENV)) ?? uat_env;
    if (currentEnv === uat_env) {
      dispatch({
        type: UAT_SIGNIN_REQUEST,
        payload: {
          email: email,
          password: password,
        },
      });
    }
    if (currentEnv === prod_env) {
      LoginUsing2FA(email, password);
    }
  };

  const LoginUsing2FA = (email, password) => {
    const url = PROD_BASE_URL + '/token';
    const config = {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    };
    const data = {
      username: email,
      password: password,
      grant_type: 'password',
    };
    axios.post(url, qs.stringify(data), config).catch(err => {
      let message = err.response.data;
      if (message.error == 'need_2fa_verification') {
        navigation.navigate(routes.Screen2FA, {
          email: email,
          password: password,
        });
      } else {
        return alert('Email/Password is incorrect');
      }
    });
  };

  const logoPressed = () => {
    if (tappedCount % 5 == 0) {
      refRBSheet.current.open();
    }
    setTappedCount(prev => prev + 1);
  };

  const switchEnvPressed = () => {
    AsyncStorage.getItem(ENV).then(currentEnv => {
      if (currentEnv === uat_env) {
        AsyncStorage.setItem(ENV, prod_env);
        AsyncStorage.setItem(BASE_URL, PROD_BASE_URL);
        setCurrentEnvironment(prod_env);
      } else {
        AsyncStorage.setItem(ENV, uat_env);
        AsyncStorage.setItem(BASE_URL, UAT_BASE_URL);
        setCurrentEnvironment(uat_env);
      }
    });
    refRBSheet.current.close();
  };

  useEffect(() => {
    AsyncStorage.getItem(ENV).then(env => {
      setCurrentEnvironment(env ?? uat_env);
    });
  }, []);

  return (
    <View style={styles.bgColor}>
      <TouchableOpacity onPress={logoPressed} activeOpacity={1}>
        <Image source={assets.synergy_logo_white} style={styles.logo} />
      </TouchableOpacity>
      <Text style={styles.text1}>
        Please enter your Synergy email address and password
      </Text>
      {/* Email */}
      <FilledTextInput
        placeholder={'Email'}
        imageSource={assets.ic_mail}
        imageStyle={styles.mail}
        inputStyle={styles.input_mail}
        styleContainer={styles.containerInput}
        value={email}
        onChangeText={onEmailChange}
        autoCapitalize={'none'}
      />
      {/* Password */}
      <View style={styles.password_container}>
        <Image source={assets.ic_padlock} style={styles.password} />
        <TextInput
          placeholder={'Password'}
          style={styles.input_password}
          onChangeText={onPasswordChange}
          value={password}
          secureTextEntry={securePassword}
        />
        <TouchableOpacity
          style={styles.visiblePassword}
          onPress={onVisiblePress}>
          {!visiblePassword ? (
            <Image source={assets.ic_eye} style={styles.eyePassword} />
          ) : (
            <Image source={assets.ic_eye_off} style={styles.eyePassword} />
          )}
        </TouchableOpacity>
      </View>

      {/* Login Button*/}
      <TouchableOpacity style={styles.login_btn} onPress={loginPressed}>
        <Text style={styles.login_btn_text}>Login</Text>
      </TouchableOpacity>

      {authReducer.loading ? <LoadingIndicator /> : null}

      {/* Forget Password  */}
      <TouchableOpacity style={styles.forgetpw_container}>
        <Text style={styles.forgetpw_text}>Forget password</Text>
      </TouchableOpacity>

      {/* Divider and Version */}
      <View style={styles.divider} />
      <Text style={styles.version}>v2.0.0</Text>

      {/* Bottom Sheet */}
      <RBSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        animationType={'slide'}
        customStyles={{
          wrapper: {
            backgroundColor: 'transparent',
          },
          draggableIcon: {
            backgroundColor: 'transparent',
          },
          container: {
            height: 160,
          },
        }}>
        <View
          style={{
            flex: 1,
          }}>
          <Text
            style={{
              textAlign: 'center',
              paddingHorizontal: 50,
            }}>
            You found the Easter egg. App is on{' '}
            {currentEnvironment ?? 'development'} endpoint.
          </Text>
          <View
            style={{
              height: 1,
              backgroundColor: 'rgba(0,0,0,0.1)',
              marginTop: 16,
            }}
          />
          <TouchableOpacity
            style={{
              marginTop: 16,
            }}
            onPress={switchEnvPressed}>
            <Text
              style={{
                textAlign: 'center',
                fontSize: 20,
                color: COLORS.blue_primary_btn,
              }}>
              Switch to{' '}
              {currentEnvironment === 'production' ? 'UAT' : 'production'}
            </Text>
          </TouchableOpacity>
        </View>
      </RBSheet>
    </View>
  );
};

const styles = StyleSheet.create({
  bgColor: {
    flex: 1,
    justifyContent: 'center',
    alignContent: 'center',
    backgroundColor: COLORS.blue_primary_bg,
    paddingHorizontal: 25,
  },
  logo: {
    height: 80,
    width: '100%',
    paddingHorizontal: 100,
    resizeMode: 'contain',
  },
  text1: {
    marginTop: 30,
    color: 'white',
    alignSelf: 'center',
    textAlign: 'center',
    fontSize: 16,
  },
  input_mail: {
    alignSelf: 'center',
    marginStart: 20,
    fontSize: 16,
    flex: 1,
  },
  mail: {
    height: 20,
    width: 20,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginStart: 16,
    tintColor: 'grey',
  },
  containerInput: {
    marginTop: 20,
  },
  password: {
    height: 20,
    width: 20,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginStart: 16,
    tintColor: 'grey',
  },
  input_password: {
    alignSelf: 'center',
    marginStart: 20,
    fontSize: 16,
    flex: 1,
  },
  password_container: {
    backgroundColor: 'white',
    height: 50,
    borderRadius: 8,
    flexDirection: 'row',
    marginTop: 20,
  },
  eyePassword: {
    height: 30,
    width: 30,
    resizeMode: 'contain',
  },
  visiblePassword: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    marginEnd: 20,
  },
  login_btn_text: {
    color: 'white',
    fontSize: 20,
    fontWeight: '500',
  },
  login_btn: {
    backgroundColor: COLORS.blue_primary_btn,
    justifyContent: 'center',
    alignItems: 'center',
    height: 50,
    borderRadius: 8,
    marginTop: 20,
  },
  forgetpw_container: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  forgetpw_text: {
    color: 'white',
    fontSize: 18,
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    marginHorizontal: -25,
    bottom: -150,
  },
  version: {
    alignSelf: 'center',
    bottom: -170,
    color: 'white',
    fontSize: 18,
  },
});
