import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';
import React, {useState, useEffect} from 'react';
import {assets} from '../../../constants';
import {COLORS} from '../../../constants/theme';
import {FilledTextInput} from '../../../components/common/FilledTextInput';
import {useDispatch, useSelector} from 'react-redux';
import {PROD_SIGNIN_REQUEST} from '../model/actions';
import LoadingIndicator from '../../../components/common/LoadingIndicator';

export default function Screen2FA({navigation, route}) {
  const [code2FA, setCode2FA] = useState('');
  const [timeExpired, setTimeExpired] = useState(120);
  const {email, password} = route.params;
  const {authReducer} = useSelector(state => state);

  useEffect(() => {
    if (authReducer.isLoggedIn) {
      console.log(authReducer.auth);
    }
    if (authReducer.error) {
      return alert('Incorrect code');
    }
  }, [authReducer]);

  const dispatch = useDispatch();

  const backButtonPressed = () => {
    navigation.goBack();
  };

  const handleInputChange = item => {
    setCode2FA(item);
  };

  const handleSubmitCode = () => {
    if (!code2FA) {
      return alert('Code cannot be empty');
    }
    dispatch({
      type: PROD_SIGNIN_REQUEST,
      payload: {
        email: email,
        password: password,
        code: code2FA,
      },
    });
  };

  useEffect(() => {
    let interval = setInterval(() => {
      if (timeExpired >= 0) {
        setTimeExpired(lastTimerCount => {
          lastTimerCount <= 1 && clearInterval(interval);
          return lastTimerCount - 1;
        });
      }
    }, 1000); //each count lasts for a second
    //cleanup the interval on complete
    return () => clearInterval(interval);
  }, []);

  return (
    <View
      style={{
        backgroundColor: COLORS.blue_primary_bg,
        flex: 1,
      }}>
      <View>
        <TouchableOpacity onPress={backButtonPressed}>
          <Image source={assets.back_icon} style={styles.backIcon} />
        </TouchableOpacity>
      </View>
      <View style={styles.container}>
        <Image source={assets.synergy_logo_white} style={styles.logo} />
        <Text style={styles.text1}>
          Please check your text messages or email inbox and enter the 2FA Code
        </Text>
        <FilledTextInput
          placeholder={'2FA Code'}
          value={code2FA}
          styleContainer={styles.containerInput}
          inputStyle={styles.input_code}
          onChangeText={handleInputChange}
          keyboardType="number-pad"
        />
        <TouchableOpacity
          style={styles.buttonContainer}
          onPress={handleSubmitCode}>
          <Text style={styles.buttonText}>Continue</Text>
        </TouchableOpacity>
        <Text style={styles.timeExpired}>
          2FA Code will expire in {timeExpired} sec(s)
        </Text>
        {authReducer.auth.loading ? <LoadingIndicator /> : null}

        {/* Divider and Version */}
      </View>
      <View
        style={{
          marginBottom: 40,
        }}>
        <View style={styles.divider} />
        <Text style={styles.version}>v2.0.0</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.blue_primary_bg,
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  backIcon: {
    height: 40,
    width: 40,
    marginTop: 50,
    tintColor: 'white',
    marginStart: 20,
  },
  logo: {
    height: 180,
    width: '80%',
    resizeMode: 'contain',
    marginTop: 60,
  },
  text1: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  containerInput: {
    marginTop: 40,
  },
  input_code: {
    alignSelf: 'center',
    marginStart: 20,
    fontSize: 16,
    flex: 1,
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
    fontWeight: '500',
  },
  buttonContainer: {
    backgroundColor: COLORS.blue_primary_btn,
    justifyContent: 'center',
    alignItems: 'center',
    height: 50,
    borderRadius: 8,
    marginTop: 20,
    width: '100%',
  },
  timeExpired: {
    color: 'white',
    fontSize: 16,
    marginTop: 20,
  },
  divider: {
    height: 1,
    color: 'white',
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  version: {
    alignSelf: 'center',
    color: 'white',
    fontSize: 18,
    marginTop: 20,
  },
});
