import {View, Text, StyleSheet, Image, TouchableOpacity} from 'react-native';
import React, {useState, useEffect} from 'react';
import {APP_PIN, assets, IS_LOGGEDIN} from '../../../constants';
import {arraysAreIdentical} from '../../../helpers';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch, useSelector} from 'react-redux';
import {SET_LOGIN_REQUEST} from '../../auth/model/actions';
import {COLORS} from '../../../constants/theme';

const MAX_LENGTH = 4;

export const PinCodeScreen = ({navigation}) => {
  const [pin, setPin] = useState([]);
  const [tempPin, setTempPin] = useState([]);
  const [dot1, setDot1] = useState(false);
  const [dot2, setDot2] = useState(false);
  const [dot3, setDot3] = useState(false);
  const [dot4, setDot4] = useState(false);

  const dispatch = useDispatch();
  const state = useSelector(state => state);

  useEffect(() => {
    switch (pin.length) {
      case 0:
        setDot1(false);
        setDot2(false);
        setDot3(false);
        setDot4(false);
        break;
      case 1:
        setDot1(true);
        setDot2(false);
        setDot3(false);
        setDot4(false);
        break;
      case 2:
        setDot1(true);
        setDot2(true);
        setDot3(false);
        setDot4(false);
        break;
      case 3:
        setDot1(true);
        setDot2(true);
        setDot3(true);
        setDot4(false);
        break;
      case 4:
        setDot1(true);
        setDot2(true);
        setDot3(true);
        setDot4(true);
        break;
    }
    if (pin.length === MAX_LENGTH) {
      if (tempPin.length > 0) {
        if (arraysAreIdentical(tempPin, pin)) {
          AsyncStorage.setItem(APP_PIN, JSON.stringify(pin));
          AsyncStorage.setItem(IS_LOGGEDIN, 'true');
          dispatch({
            type: SET_LOGIN_REQUEST,
          });
        } else {
          setPin([]);
          setTempPin([]);
          alert('Pin does not match');
        }
      } else {
        setTimeout(() => {
          setTempPin(pin);
          setPin([]);
        }, 200);
      }
      return;
    }
  }, [pin]);

  const handlePress = num => {
    setPin(prev => [...prev, num]);
  };

  const renderBtn = num => {
    return (
      <Text style={styles.btnNumber} onPress={() => handlePress(num)}>
        {num}
      </Text>
    );
  };

  const handleRemove = () => {
    const removeArr = [...pin];
    removeArr.pop();
    setPin(removeArr);
  };

  const renderRemoveBtn = () => {
    return (
      <TouchableOpacity onPress={handleRemove}>
        <Image source={assets.ic_delete} style={styles.removeBtn} />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Image source={assets.synergy_logo_white} style={styles.logo} />
      {tempPin.length > 0 ? (
        <Text style={styles.text1}>Re-enter your PIN</Text>
      ) : (
        <Text style={styles.text1}>
          Create your PIN. This PIN will be used whenever we need to
          re-authenticate you.
        </Text>
      )}
      <View style={styles.dotContainer}>
        <Text style={[styles.dotStyle, {opacity: dot1 ? 100 : 0}]}>•</Text>
        <Text style={[styles.dotStyle, {opacity: dot2 ? 100 : 0}]}>•</Text>
        <Text style={[styles.dotStyle, {opacity: dot3 ? 100 : 0}]}>•</Text>
        <Text style={[styles.dotStyle, {opacity: dot4 ? 100 : 0}]}>•</Text>
      </View>
      <View style={styles.numberContainer}>
        <Text style={styles.numberStyle}>____</Text>
        <Text style={styles.numberStyle}>____</Text>
        <Text style={styles.numberStyle}>____</Text>
        <Text style={styles.numberStyle}>____</Text>
      </View>
      <View style={styles.numberRow}>
        {renderBtn(1)}
        {renderBtn(2)}
        {renderBtn(3)}
      </View>
      <View style={styles.numberRow}>
        {renderBtn(4)}
        {renderBtn(5)}
        {renderBtn(6)}
      </View>
      <View style={styles.numberRow}>
        {renderBtn(7)}
        {renderBtn(8)}
        {renderBtn(9)}
      </View>
      <View style={styles.numberRow}>
        {renderBtn('')}
        {renderBtn(0)}
        {renderRemoveBtn()}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.blue_primary_bg,
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  logo: {
    height: 180,
    width: '100%',
    resizeMode: 'contain',
    marginTop: 50,
  },
  text1: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  numberStyle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 30,
    marginStart: 15,
    marginEnd: 15,
  },
  numberContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  dotContainer: {
    flexDirection: 'row',
    marginTop: 50,
    marginBottom: -20,
  },
  dotStyle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 40,
    marginStart: 30,
    marginEnd: 30,
  },
  numberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 50,
    left: 5,
  },
  btnNumber: {
    fontSize: 20,
    color: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 50,
    textAlign: 'center',
    fontWeight: '500',
  },
  removeBtn: {
    height: 30,
    width: 30,
    paddingHorizontal: 55,
    resizeMode: 'contain',
    left: 2,
  },
});
