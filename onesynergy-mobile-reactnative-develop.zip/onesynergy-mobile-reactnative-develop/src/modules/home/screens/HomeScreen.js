import {
  View,
  Text,
  StatusBar,
  StyleSheet,
  Image,
  ScrollView,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {APP_PIN, assets} from '../../../constants';
import EventsAndWeather from '../../../components/home/EventsAndWeather';
import Feedback from '../../../components/home/Feedback';
import UserInfo from '../../../components/home/UserInfo';
import NewsUpdate from '../../../components/home/NewsUpdate';
import SliderItems from '../../../components/home/SliderItems';
import Header from '../../../components/common/Header';
import {useDispatch, useSelector} from 'react-redux';
import {GET_USER_REQUEST} from '../model/actions';

const UATimg = 'https://1uat.synergy.com.sg';
const PRODimg = 'https://1.synergy.com.sg';

const HomeScreen = () => {
  const [hasUpdate, setHasUpdate] = useState(true);
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState('');
  const [userImg, setUserImg] = useState('');

  const dispatch = useDispatch();
  const {userReducer, authReducer} = useSelector(state => state);

  useEffect(() => {
    AsyncStorage.getItem(APP_PIN).then(pin => {
      //   console.log('PIN', pin);
    });
  }, []);

  useEffect(() => {
    if (authReducer.userId) {
      const userId = authReducer.userId;
      dispatch({
        type: GET_USER_REQUEST,
        payload: {
          userId: userId,
        },
      });
    }
  }, [authReducer]);

  useEffect(() => {
    setUserName(userReducer.name);
    setUserRole(userReducer.designation);
    if (userReducer.photoUrl === UATimg || PRODimg) {
      setUserImg('');
    } else {
      setUserImg(userReducer.photoUrl);
    }
  }, [userReducer]);

  return (
    <View>
      <Header ScreenTitle={'Good Morning!'} HasWeather={true} />
      <ScrollView style={{paddingBottom: 60}}>
        {/* User profile */}
        <View>
          <UserInfo img={userImg} username={userName} role={userRole} />
        </View>

        {/* New update */}

        <View>{hasUpdate ? <NewsUpdate /> : null}</View>

        {/* Carousel */}
        <View
          style={{
            marginTop: 16,
          }}>
          <SliderItems />
        </View>

        {/* Upcoming Events and Tomorrow Events */}
        <View style={styles.eventsContainer}>
          <EventsAndWeather
            eventType={'Upcoming Events'}
            weatherData={'29'}
            noEventText={'There are no more events coming up today.'}
          />
          <EventsAndWeather
            eventType={'Tomorrow Events'}
            weatherData={'10'}
            noEventText={'There are no more events coming up tomorrow.'}
            style={{marginTop: 16}}
          />
        </View>

        {/* FeedBack */}
        <View
          style={{
            alignItems: 'center',
            marginTop: 50,
          }}>
          <Feedback />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    marginBottom: 10,
    flexDirection: 'row',
    flex: 1,
    justifyContent: 'center',
    marginStart: 50,
  },
  welcomeText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 3,
  },
  weatherImg: {
    width: 30,
    height: 30,
  },
  chatIcon: {
    height: 24,
    width: 24,
  },
  eventsContainer: {
    marginStart: 20,
    marginTop: 30,
  },
});

export default HomeScreen;
