import {call, put, takeEvery, takeLatest} from 'redux-saga/effects';
import {USER_DATA_URL} from '../../../config/api';
import {queryApi} from '../../../redux/query-api';
import {GET_USER_FAILURE, GET_USER_REQUEST, GET_USER_SUCCESS} from './actions';

function* userHandler() {
  yield takeEvery(GET_USER_REQUEST, getUserData);
}

function* getUserData(action) {
  try {
    const response = yield call(queryApi, {
      endpoint: USER_DATA_URL + action.payload.userId,
      method: 'GET',
    });

    if (response.status === 200) {
      yield put({
        type: GET_USER_SUCCESS,
        payload: response.response,
      });
    } else {
      yield put({
        type: GET_USER_FAILURE,
        payload: response.error_response,
      });
    }
  } catch (err) {
    yield put({
      type: GET_USER_FAILURE,
      payload: err,
    });
    console.log('err', err);
  }
}

export {userHandler};
