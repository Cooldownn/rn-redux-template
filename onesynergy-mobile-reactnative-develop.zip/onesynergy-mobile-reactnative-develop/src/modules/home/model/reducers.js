import {GET_USER_FAILURE, GET_USER_REQUEST, GET_USER_SUCCESS} from './actions';

const initialState = {
  biodata: '',
  photoUrl: '',
  isRoleId: [],
  name: '',
  dob: '',
  designation: '',
  department: '',
  email: '',
  phoneNumber: '',
  mobileProductionUAT: false,
  isMobileBeta: false,
  isWebBeta: false,
  adviserData: null,
  loading: false,
  error: '',
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_USER_REQUEST:
      return {
        ...state,
        loading: true,
      };

    case GET_USER_SUCCESS:
      return {
        ...state,
        biodata: action.payload.biodata ?? '',
        photoUrl: action.payload.photoUrl ?? '',
        isRoleId: action.payload.IsRoleId ?? '',
        name: action.payload.name ?? '',
        dob: action.payload.dob ?? '',
        designation: action.payload.designation ?? '',
        department: action.payload.department ?? '',
        email: action.payload.email ?? '',
        phoneNumber: action.payload.phoneNumber ?? '',
        mobileProductionUAT: action.payload.mobileProductionUAT ?? false,
        isMobileBeta: action.payload.isMobileBeta ?? false,
        isWebBeta: action.payload.isWebBeta ?? false,
        adviserData: action.payload.adviserData ?? null,
        loading: false,
        error: '',
      };

    case GET_USER_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload.error_description,
      };

    default:
      return state;
  }
};

export {userReducer};
