import AsyncStorage from '@react-native-async-storage/async-storage';

export const isEmpty = value => {
  return !value || value.length === 0;
};

export const arraysAreIdentical = (arr1, arr2) => {
  if (arr1.length !== arr2.length) return false;
  for (var i = 0, len = arr1.length; i < len; i++) {
    if (arr1[i] !== arr2[i]) {
      return false;
    }
  }
  return true;
};

export const getStringFromLocalStorage = async key => {
  try {
    return await AsyncStorage.getItem(key);
  } catch (err) {
    console.log(err);
  }
};
