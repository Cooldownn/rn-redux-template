import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import routes from '../constants/routes';
import HomeScreen from '../modules/home/screens/HomeScreen';

const HomeTab = createNativeStackNavigator();

const HomeStack = () => {
  return (
    <HomeTab.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <HomeTab.Screen
        name={routes.HOME_SCREEN}
        component={HomeScreen}
        options={{
          headerShown: false,
        }}
      />
    </HomeTab.Navigator>
  );
};

export default HomeStack;
