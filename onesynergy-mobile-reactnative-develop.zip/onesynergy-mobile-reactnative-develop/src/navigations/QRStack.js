import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import routes from '../constants/routes';
import QRScreen from '../modules/qrcode/screens/QRScreen';

const QRTab = createNativeStackNavigator();

const QRStack = () => {
  return (
    <QRTab.Navigator screenOptions={{headerShown: false}}>
      <QRTab.Screen
        name={routes.QR_SCREEN}
        component={QRScreen}
        options={{
          headerShown: false,
        }}
      />
    </QRTab.Navigator>
  );
};

export default QRStack;
