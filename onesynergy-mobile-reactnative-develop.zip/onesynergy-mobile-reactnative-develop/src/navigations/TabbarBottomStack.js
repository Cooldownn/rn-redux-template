import {View, Text, Image, StatusBar} from 'react-native';
import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import HomeStack from './HomeStack';
import MenuStack from './MenuStack';
import QRStack from './QRStack';
import NotificationStack from './NotificationStack';
import SettingStack from './SettingStack';
import routes from '../constants/routes';
import {assets} from '../constants';
import {COLORS} from '../constants/theme';

const Tab = createBottomTabNavigator();

const TabbarBottomStack = () => {
  return (
    <>
      <SafeAreaProvider style={{flex: 1, backgroundColor: 'white'}}>
        <Tab.Navigator
          screenOptions={{
            headerShown: false,
            tabBarStyle: {height: 80},
          }}
          initialRouteName={routes.HOME_STACK}>
          <Tab.Screen
            name={routes.HOME_STACK}
            component={HomeStack}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => (
                <Image
                  source={assets.ic_home}
                  style={{
                    width: 24,
                    height: 24,
                    resizeMode: 'contain',
                    tintColor: focused
                      ? COLORS.blue_primary_btn
                      : COLORS.grey_tabbar,
                    marginTop: 16,
                  }}
                />
              ),
            }}
          />
          <Tab.Screen
            name={routes.MENU_STACK}
            component={MenuStack}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => (
                <Image
                  source={assets.ic_shortcuts}
                  style={{
                    width: 24,
                    height: 24,
                    resizeMode: 'contain',
                    tintColor: focused
                      ? COLORS.blue_primary_btn
                      : COLORS.grey_tabbar,
                    marginTop: 16,
                  }}
                />
              ),
            }}
          />
          <Tab.Screen
            name={routes.QR_STACK}
            component={QRStack}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => (
                <Image
                  source={assets.ic_scanner}
                  style={{
                    width: 24,
                    height: 24,
                    resizeMode: 'contain',
                    tintColor: focused
                      ? COLORS.blue_primary_btn
                      : COLORS.grey_tabbar,
                    marginTop: 16,
                  }}
                />
              ),
            }}
          />
          <Tab.Screen
            name={routes.NOTIFICATION_STACK}
            component={NotificationStack}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => (
                <Image
                  source={assets.ic_notification}
                  style={{
                    width: 24,
                    height: 24,
                    resizeMode: 'contain',
                    tintColor: focused
                      ? COLORS.blue_primary_btn
                      : COLORS.grey_tabbar,
                    marginTop: 16,
                  }}
                />
              ),
            }}
          />
          <Tab.Screen
            name={routes.SETTING_STACK}
            component={SettingStack}
            options={{
              tabBarLabel: '',
              tabBarIcon: ({focused}) => (
                <Image
                  source={assets.ic_profile}
                  style={{
                    width: 24,
                    height: 24,
                    resizeMode: 'contain',
                    tintColor: focused
                      ? COLORS.blue_primary_btn
                      : COLORS.grey_tabbar,
                    marginTop: 16,
                  }}
                />
              ),
            }}
          />
        </Tab.Navigator>
      </SafeAreaProvider>
    </>
  );
};

export default TabbarBottomStack;
