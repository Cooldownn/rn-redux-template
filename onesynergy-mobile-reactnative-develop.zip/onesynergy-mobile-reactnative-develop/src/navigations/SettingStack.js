import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import routes from '../constants/routes';
import SettingScreen from '../modules/setting/screens/SettingScreen';

const SettingTab = createNativeStackNavigator();

const SettingStack = () => {
  return (
    <SettingTab.Navigator screenOptions={{headerShown: false}}>
      <SettingTab.Screen
        name={routes.SETTING_SCREEN}
        component={SettingScreen}
        options={{
          headerShown: false,
        }}
      />
    </SettingTab.Navigator>
  );
};

export default SettingStack;
