import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import routes from '../constants/routes';
import MenuScreen from '../modules/menu/screens/MenuScreen';

const MenuTab = createNativeStackNavigator();

const MenuStack = () => {
  return (
    <MenuTab.Navigator screenOptions={{headerShown: false}}>
      <MenuTab.Screen
        name={routes.MENU_SCREEN}
        component={MenuScreen}
        options={{
          headerShown: false,
        }}
      />
    </MenuTab.Navigator>
  );
};

export default MenuStack;
