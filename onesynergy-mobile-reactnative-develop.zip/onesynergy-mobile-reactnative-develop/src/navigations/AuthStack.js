import React from 'react';
import {LoginScreen} from '../modules/auth/screens/LoginScreen';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {PinCodeScreen} from '../modules/auth/screens/PinCodeScreen';
import routes from '../constants/routes';
import Screen2FA from '../modules/auth/screens/Screen2FA';

const LoginStack = createNativeStackNavigator();

export const AuthStack = () => {
  return (
    <LoginStack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <LoginStack.Screen
        name={routes.LOGIN_SCREEN}
        component={LoginScreen}
        options={{
          headerShown: false,
        }}
      />
      <LoginStack.Screen
        name={routes.PINCODE_SCREEN}
        component={PinCodeScreen}
      />
      <LoginStack.Screen name={routes.Screen2FA} component={Screen2FA} />
    </LoginStack.Navigator>
  );
};
