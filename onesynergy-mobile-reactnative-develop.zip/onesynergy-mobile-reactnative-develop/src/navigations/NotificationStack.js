import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import routes from '../constants/routes';
import NotificationScreen from '../modules/notification/screens/NotificationScreen';

const NotificationTab = createNativeStackNavigator();

const NotificationStack = () => {
  return (
    <NotificationTab.Navigator screenOptions={{headerShown: false}}>
      <NotificationTab.Screen
        name={routes.NOTIFICATION_SCREEN}
        component={NotificationScreen}
        options={{
          headerShown: false,
        }}
      />
    </NotificationTab.Navigator>
  );
};

export default NotificationStack;
