import React, {useEffect, useState} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import TabbarBottomStack from './TabbarBottomStack';
import {AuthStack} from './AuthStack';
import {createStackNavigator} from '@react-navigation/stack';
import routes from '../constants/routes';
import {getStringFromLocalStorage} from '../helpers';
import {IS_LOGGEDIN} from '../constants';
import {useDispatch, useSelector} from 'react-redux';
import {SET_LOGIN_REQUEST} from '../modules/auth/model/actions';

const Main = createStackNavigator();

export const RootStack = () => {
  const {
    authReducer: {isLoggedIn},
  } = useSelector(state => state);

  const dispatch = useDispatch();

  useEffect(() => {
    getStringFromLocalStorage(IS_LOGGEDIN).then(value => {
      if (value === 'true') {
        dispatch({
          type: SET_LOGIN_REQUEST,
        });
      }
    });
  }, []);

  return (
    <>
      <SafeAreaProvider>
        <NavigationContainer>
          <Main.Navigator screenOptions={{headerShown: false}}>
            {isLoggedIn ? (
              <Main.Screen
                name={routes.TABBAR_STACK}
                component={TabbarBottomStack}
              />
            ) : (
              <Main.Screen name={routes.AUTH_STACK} component={AuthStack} />
            )}
            {/* <Main.Screen
              name={routes.TABBAR_STACK}
              component={TabbarBottomStack}
            /> */}
          </Main.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </>
  );
};
