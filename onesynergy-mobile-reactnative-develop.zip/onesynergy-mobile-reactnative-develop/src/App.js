import React, {useEffect, useState} from 'react';
import {StyleSheet, Text, View, Image, LogBox} from 'react-native';
import {assets, BASE_URL, ENV, uat_env} from './constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Provider} from 'react-redux';
import {store} from './redux/store';
import {RootStack} from './navigations/RootStack';
import {UAT_BASE_URL} from './config/api';
import NetInfo from '@react-native-community/netinfo';

if (!__DEV__) {
  LogBox.ignoreAllLogs();
}

LogBox.ignoreLogs(['ViewPropTypes will be removed from React Native']);

export default function App() {
  const [splashTimer, setSplashTimer] = useState(true);
  const [isOffline, setOfflineStatus] = useState(false);
  AsyncStorage.setItem(ENV, uat_env);
  AsyncStorage.setItem(BASE_URL, UAT_BASE_URL);

  useEffect(() => {
    setTimeout(() => {
      setSplashTimer(false);
    }, 2000);
  }, []);

  // useEffect(() => {
  //   const removeNetInfoSubscription = NetInfo.addEventListener(state => {
  //     const offline = !(state.isConnected && state.isInternetReachable);
  //     setOfflineStatus(offline);
  //   });

  //   // Do something if connection is OK

  //   return () => removeNetInfoSubscription();
  // }, []);

  return (
    <Provider store={store}>
      <View style={styles.container}>
        {splashTimer ? (
          <Image source={assets.splash_logo} style={styles.splash_logo} />
        ) : (
          <RootStack />
        )}
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  splash_logo: {
    height: 180,
    width: '100%',
    resizeMode: 'contain',
  },
});
