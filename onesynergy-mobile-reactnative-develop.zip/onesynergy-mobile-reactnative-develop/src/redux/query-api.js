import {call, select} from 'redux-saga/effects';
import {BASE_URL} from '../constants';
import {UAT_BASE_URL, PROD_BASE_URL} from '../config/api';
import qs from 'qs';
import {getStringFromLocalStorage} from '../helpers';

function* queryApi({endpoint, method, body = null}) {
  const state = yield select();
  const res = yield call(makeRequest, {
    endpoint,
    method,
    headers: {
      Authorization: state.authReducer.accessToken
        ? `Bearer ${state.authReducer.accessToken}`
        : null,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: body,
  });

  if (res.status === 401) {
    // Log the user out
    // Explain that they need to log back in
  }
  if (res.status === 503) {
    alert('Service is unavailable. Please try again later');
  }

  const parsedResponse = yield call(parseResponse, res);
  if (!res.ok) {
    // Handle bad response here
    return {
      status: res.status,
      error_response: parsedResponse,
    };
  }

  return {
    status: res.status,
    response: parsedResponse,
  };
}

const makeRequest = async ({endpoint, method, headers, body = null}) => {
  // TODO: Change Endpoint to base UAT
  const baseUrl = (await getStringFromLocalStorage(BASE_URL)) ?? UAT_BASE_URL;
  return fetch(baseUrl + endpoint, {
    method,
    headers,
    body: body === {} ? undefined : qs.stringify(body),
  });
};

const parseResponse = async response => {
  let parsedResponse;
  try {
    parsedResponse = await response.clone().json();
  } catch {
    parsedResponse = await response.text();
  }

  return parsedResponse;
};

export {queryApi};
