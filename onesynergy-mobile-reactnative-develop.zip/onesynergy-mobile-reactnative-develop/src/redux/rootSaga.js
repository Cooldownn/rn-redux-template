import {all, fork} from 'redux-saga/effects';
import {authHandler} from '../modules/auth/model/sagas';
import {userHandler} from '../modules/home/model/sagas';
export default function* rootSaga() {
  yield all([fork(authHandler), fork(userHandler)]);
}
