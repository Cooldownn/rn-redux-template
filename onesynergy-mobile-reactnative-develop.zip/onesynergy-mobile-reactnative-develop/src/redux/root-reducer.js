import {combineReducers} from 'redux';
import {authReducer} from '../modules/auth/model/reducers';
import {userReducer} from '../modules/home/model/reducers';

const reducer = combineReducers({
  authReducer: authReducer,
  userReducer: userReducer,
});

export default reducer;
